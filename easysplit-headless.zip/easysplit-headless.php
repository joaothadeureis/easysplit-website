<?php
/**
 * Plugin Name: EasySplit Headless Mode
 * Description: Configura o WordPress como CMS headless para o site React
 * Version: 1.0
 * Author: EasySplit
 */

// Evitar acesso direto
if (!defined('ABSPATH')) exit;

// Modificar URLs no sitemap do Rank Math
add_filter('rank_math/sitemap/url', function($url) {
    if (strpos($url, '/wp/') !== false && strpos($url, '/wp/wp-') === false) {
        $url = preg_replace('#/wp/([a-z0-9-]+)/?$#i', '/blog/$1', $url);
    }
    return $url;
});

add_filter('rank_math/sitemap/entry', function($entry, $type, $object) {
    if (isset($entry['loc'])) {
        if ($type === 'post' || (isset($object->post_type) && $object->post_type === 'post')) {
            $entry['loc'] = preg_replace('#/wp/([a-z0-9-]+)/?$#i', '/blog/$1', $entry['loc']);
        }
        if (strpos($entry['loc'], '/wp/category/') !== false) {
            $entry['loc'] = str_replace('/wp/category/', '/blog/categoria/', $entry['loc']);
        }
    }
    return $entry;
}, 10, 3);

// Redirecionar front-end para o React
add_action('template_redirect', function() {
    if (is_admin()) return;
    if (defined('REST_REQUEST') && REST_REQUEST) return;
    if (strpos($_SERVER['REQUEST_URI'], 'wp-admin') !== false) return;
    if (strpos($_SERVER['REQUEST_URI'], 'wp-json') !== false) return;
    if (strpos($_SERVER['REQUEST_URI'], 'wp-login') !== false) return;
    if (strpos($_SERVER['REQUEST_URI'], 'wp-content') !== false) return;
    if (strpos($_SERVER['REQUEST_URI'], 'sitemap') !== false) return;
    
    $redirect_url = null;
    
    if (is_single()) {
        $redirect_url = 'https://easysplit.com.br/blog/' . get_post_field('post_name', get_the_ID());
    } elseif (is_category()) {
        $redirect_url = 'https://easysplit.com.br/blog/categoria/' . get_queried_object()->slug;
    } elseif (is_tag()) {
        $redirect_url = 'https://easysplit.com.br/blog';
    } elseif (is_author() || is_archive() || is_home()) {
        $redirect_url = 'https://easysplit.com.br/blog';
    }
    
    if ($redirect_url) {
        wp_redirect($redirect_url, 301);
        exit;
    }
});

// Desabilitar sitemap nativo do WordPress
add_filter('wp_sitemaps_enabled', '__return_false');

// Noindex fallback
add_action('wp_head', function() {
    if (!is_admin() && !is_page()) {
        echo '<meta name="robots" content="noindex, nofollow">' . "\n";
    }
}, 1);

// Canonical URLs para o React
add_filter('rank_math/frontend/canonical', function($canonical) {
    if (is_single()) {
        return 'https://easysplit.com.br/blog/' . get_post_field('post_name', get_the_ID());
    }
    if (is_category()) {
        return 'https://easysplit.com.br/blog/categoria/' . get_queried_object()->slug;
    }
    return $canonical;
});